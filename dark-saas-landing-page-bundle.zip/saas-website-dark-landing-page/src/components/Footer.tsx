export const Footer = () => {
  return null;
};
