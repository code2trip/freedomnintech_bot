export const Banner = () => {
  return null;
};
