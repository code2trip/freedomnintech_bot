export const Hero = () => {
  return null;
};
