import appScreen from "../assets/images/app-screen.png";

export const ProductShowcase = () => {
  return null;
};
